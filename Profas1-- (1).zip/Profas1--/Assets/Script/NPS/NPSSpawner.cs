using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPSSpawner : MonoBehaviour
{
    //public [] windowPoints;
    //private Transform[] spawnPoint; 

    void Start()
    {
        //windowPoints = FindObjectsOfType<>();
        //Debug.Log($"Window Ponts = {windowPoints.Length}");
        //for(int i = 0; i < windowPoints.Length; i++)
        //{
        //    Debug.Log($"{i}");
        //    spawnPoint[i] = windowPoints[i].spawnPoint;
        //}
    }

    void Update()
    {
        
    }
}
