//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class RatMover : MonoBehaviour
//{
//    [SerializeField] private float moveSpeed;
//    [SerializeField] private Transform[] targetPoints;
//    private int index;

//    void Start()
//    {
        
//    }

//    void Update()
//    {
//        moveToPoint();
//    }

//    private void moveToPoint()
//    {
//        transform.Translate(new Vector2(targetPoints.p)* moveSpeed * Time.deltaTime);
//    }
//}
